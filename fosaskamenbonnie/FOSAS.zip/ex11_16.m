% Example 11.16
%
num = [1 0 -1];
den = [1 0 2 4];
x = dimpulse(num,den,20)