% Figure 1.15
%
n = -2:6;
x = [0 0 1 2 1 0 -1 0 0];
stem(n,x);
xlabel('n')
ylabel('x[n]')
title('Figure 1.15')