% Example 8.16
num = [ 1 2];
den = [1 4 3 0];
[r,p] = residue(num,den)
