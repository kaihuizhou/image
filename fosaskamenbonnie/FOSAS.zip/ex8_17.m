% Example 8.17
num = [ 1 -2 1];
den = [1 3 4 2];
[r,p] = residue(num,den)