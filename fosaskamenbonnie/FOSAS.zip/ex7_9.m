% Example 7.9
Xk = [6 -1-j 0 -1+j].';
x = idft(Xk)