% Example 8.24
%
clf
num = [1 2];
den = [1 4 3 0];
impulse(num,den);