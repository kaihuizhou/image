% Example 7.16
%  The first part requires the Symbolic Toolbox.
syms X x z
X = (8*z^3+2*z^2-5*z)/(z^3-1.75*z+.75);
x = iztrans(X)

% This part does not require the Symbolic Toolbox.
q = 10;
num = [8 2 -5 0];
den = [1 0 -1.75 .75];
x = filter(num,den,[1 zeros(1,q-1)])