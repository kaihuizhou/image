% Example 7.22
% Part of this code uses the Symbolic Toolbox.  Comment that part of the 
%  code if that toolbox is not available.

num = [2.898 -1.449 0];
den = [1 -.866 .25];
n = 0:20;

% if dstep is available, use y = dstep(num,den,21);
% otherwise, use

u = ones(length(n));
y = filter(num,den,u);
stem(n,y,'filled')
title('Figure 7.3')
xlabel('n')
ylabel('y[n]')
display('Hit return to continue');
pause
% the following uses the Symbolic Math Toolbox
syms z X Y y n
X = z/(z-1);
H = (2.898*z^2-1.449*z)/(z^2-.866*z+.25);
Y = H*X
y = iztrans(Y);
simplify(y)
ezplot(y)
