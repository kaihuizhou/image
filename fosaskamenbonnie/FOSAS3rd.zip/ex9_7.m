% Example 9.7
num = 1;
den = [ 1 .1 0];
rlocus(num,den)