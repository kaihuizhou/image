%  Example 1.3
%  reads data file and plots closing price of QQQQ
c=csvread('QQQQdata1.csv',1,4,[1 4 10 4]);
n=1:10;
plot(n,c(n),n,c(n),'o')
grid
xlabel('Day (n)')
ylabel('Closing Price')
title('Figure 1.22')
