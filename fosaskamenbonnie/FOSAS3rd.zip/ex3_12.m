% Example 3.12
% spectrum of a decaying sinusoid

syms x t X w 

% b = 2
a = 2; b = 2;
x = exp(-a*t)*sin(b*pi*t);
X = simplify(int(x*exp(-j*w*t),t,0,inf))

% results in X = -2*pi/(-4+w^2-4*pi^2-4*i*w)
% the following commands plot the signal
tp = 0:.01:3;
xp = exp(-2*tp).*sin(2*pi*tp);
figure(1)
subplot(211),plot(tp,xp)
xlabel('Time (sec)')
ylabel('x(t)')
wp = 0:.05:50;
Xp = -2*pi./(-4+wp.^2-4*pi^2-4*i*wp);
subplot(212),plot(wp,abs(Xp))
xlabel('Frequency (rad/sec)')
ylabel('|X|')
subplot(111)

% b = 10
a = 2; b = 10;
x = exp(-a*t)*sin(b*pi*t);
X = simplify(int(x*exp(-j*w*t),t,0,inf))

% results in X = -10*pi/(-4+w^2-100*pi^2-4*i*w)
% the following commands plot the signal
tp = 0:.01:3;
xp = exp(-a*tp).*sin(b*pi*tp);
figure(2)
subplot(211),plot(tp,xp)
xlabel('Time (sec)')
ylabel('x(t)')
omegap = 0:.05:50;
Xp = -10*pi./(-4+wp.^2-100*pi^2-4*i*wp);
subplot(212),plot(wp,abs(Xp))
xlabel('Frequency (rad/sec)')
ylabel('|X|')
subplot(111)