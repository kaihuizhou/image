%  Example 5.28
%  compares frequency response of WMA filter and double WMA filter
%  dotted curve is the frequency response of the WMA filter
W=0:.01:1; 
H1=.25+.5*exp(-j*W*pi)+.25*exp(-j*2*W*pi);
H2=H1.*H1;
magH1=abs(H1);
magH2=abs(H2);
plot(W,magH2,'k',W,magH1,'k.')
grid
xlabel('Normalized frequency')
ylabel('Magnitude function')
title('Figure 5.28')

