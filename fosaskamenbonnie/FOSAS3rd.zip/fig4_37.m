%  Figure 4.37 
%  ramp subtracted from closing price
c=csvread('QQQQdata2.csv',1,4,[1 4 50 4]);
x=[];
for n=1:50;
    x(n)=c(n)-c(1)+(c(1)-c(50))*(n-1)/49;
end;
n=1:50;
H=plot(n,x,'k');
h=[];
grid
xlabel('n')
ylabel('x[n]')
%title('Figure 4.37')
pubplot
print -dill \book\plotting\fig4_37
