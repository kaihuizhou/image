%  Example 8.6
% first order step response
%
% method using the command STEP
p = 1; 
t = 0:.01:2;
num = 1; den = [1 -p];
H = tf(num,den);
y1 = step(H,t);
p = 2; 
den = [1 -p];
H = tf(num,den);
y2 = step(H,t);
p = 3; 
den = [1 -p];
H = tf(num,den);
y3 = step(H,t);
plot(t,y1,'-',t,y2,'--',t,y3,'-.');
legend('p = 1','p = 2','p = 3');
xlabel('Time (sec)')
ylabel('y(t)')
title('First order step response')

pause
%
p = -1; 
t = 0:.05:10;
num = -p; den = [1 -p];
H = tf(num,den);
y1 = step(H,t);
p = -2; 
num = -p; den = [1 -p];
H = tf(num,den);
y2 = step(H,t);
p = -5; 
num = -p; den = [1 -p];
H = tf(num,den);
y3 = step(H,t);
plot(t,y1,'-',t,y2,'--',t,y3,'-.');
legend('p = -1','p = -2','p = -5'); 
xlabel('Time (sec)')
ylabel('y(t)')
title('First order step response')

% method using the symbolic manipulator
syms X H y s
p = -1;
X = 1/s;  H = 1/(s-p);
y = ilaplace(H*X);
ezplot(y)
axis([0 5 0 1])
title('Example 8.6')
ylabel('y(t)'); xlabel('Time (sec)')
