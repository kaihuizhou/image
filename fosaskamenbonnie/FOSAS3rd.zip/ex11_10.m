% Example 11.10

kf = .1; m=1;
A = [0 1;0 -kf/m]; B = [0 1/m]'; C = [1 0];
T = 0.1;
[Ad,Bd] = c2d(A,B,T)
