%  Figure 4.34
%  Ampitude spectrum of sunspot data
spd=csvread('sunspotdata.csv',0,2,[0 2 299 2]);
x=spd-(1/300)*sum(spd);
X=abs(fft(x));
k=0:299;
h=[];
H=plot(k,X(k+1),'k');
xlabel('k')
ylabel('|Xk|');
%title('Figure 4.34')
pubplot
print -dill \book\plotting\fig4_34
