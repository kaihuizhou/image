%  Figure 4.39
%  x[n] and the smoothed version of x[n]
c=csvread('QQQQdata2.csv',1,4,[1 4 50 5]);
for n=1:50;
    x(n)=c(n)-c(1)+(c(1)-c(50))*(n-1)/49;
end;
n=1:50;
y=-0.372*cos(0.04*pi*n)-1.383*sin(0.04*pi*n);
plot(n,x(n),n,y(n))
grid
xlabel('n')
ylabel('x[n] and the approximation to x[n]')
title('Figure 4.39')
