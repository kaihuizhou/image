% Example 8.16
%   Response to a sinusoid
%

% The user should remove the portions of the code that require a toolbox
% that he or she does not have.

% This portion of the code requires the Control Systems Toolbox.
t = 0:0.05:20;
num = 1; den = [1 1];
H = tf(num,den);
x = 10*cos(1.5*t);
y = lsim(H,x,t);
plot(t,y)
grid
title('Example 8.16')
ylabel('y(t)')
xlabel('Time (sec)')

% This portion of the code requires the Symbolic Math Toolbox.
syms X H y s
X = 10*s/(s^2+1.5^2);  H = 1/(s+1);
y = ilaplace(H*X);
ezplot(y,[0 20])
axis([0 20 -6 6])
title('Example 9.17')
ylabel('y(t)')
xlabel('Time (sec)')
grid