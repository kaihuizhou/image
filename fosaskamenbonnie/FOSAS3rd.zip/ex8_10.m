%  Example 8.10
% second order response
%  poles are -1 + 4j and -1 - 4j

% The user should remove portions of the code that require a
%   toolbox that he/she does not have.

% This portion of the code requires the Control Systems Toolbox.
num = 17; den = [1 2 17];
t = 0:10/300:10;
y = step(num,den,t);
env = 1-sqrt(17)/4*exp(-t);
plot(t,y,t,env,'--');
xlabel('Time (sec)')
ylabel('y(t)')
title('Second order step response')
legend('y(t)','envelope of decay')

% This portion of the code requires the Symbolic Math Toolbox.
syms Y y s
Y = 17/(s^3+2*s^2+17*s);
y = ilaplace(Y);
ezplot(y,[0, 10])
axis([0 10 0 2])
xlabel('Time (sec)')
ylabel('y(t)')
title('Second order step response')


