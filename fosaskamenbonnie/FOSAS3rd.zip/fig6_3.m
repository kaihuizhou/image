% figure 6.3
t = 0:.02:10;
x = 2/3-exp(-t)/2-exp(-3*t)/6;
h=[];
H=plot(t,x,'k',t,ones(size(t))*2/3,'k:');
xlabel('Time (sec)')
ylabel('Amplitude')
title('Impulse Response')
pubplot
print -dill \book\plotting\fig6_3

