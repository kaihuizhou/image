%  Figure 7.13
%  plots difference in filter outputs (MACD signal)
c=csvread('QQQQdata4.csv',1,4,[1 4 100 4]);
y1(1)=c(1);
for i=2:100;
    y1(i)=y1(i-1)+.4*(c(i)-y1(i-1));
end;
y2(1)=c(1);
for i=2:100;
    y2(i)=y2(i-1)+.2*(c(i)-y2(i-1));
    D(i)=y1(i)-y2(i);
end;
n=2:100;
plot(n,D(n),'k',n,D(n),'k.')
grid
xlabel('Day (n)')
ylabel('Difference in filter outputs')
title('Figure 7.13')


