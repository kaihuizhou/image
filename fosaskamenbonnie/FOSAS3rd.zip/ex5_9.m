%  Example 5.9
%  plots magnitude and phase functions of 2-point MA filter
W=0:.01:1; 
H=(1/2)*(1-exp(-j*2*pi*W))./(1-exp(-j*pi*W));
magH=abs(H);
angH=180*angle(H)/pi;
subplot(211),plot(W,magH)
grid
xlabel('Normalized frequency')
ylabel('|H|')
title('Figure 5.22 (a)')
subplot(212),plot(W,angH)
grid
xlabel('Normalized frequency')
ylabel('angle(H) in degrees')
title('Figure 5.22 (b)')
subplot(111)
