%  Figure 5.29
%  plots output y[n] of double WMA filter applied to closing price c[n] of QQQQ
%  c[n] plotted using o's
%  y[n] plotted usiing *'s
%  QQQQdata2.csv must have been downloaded from the web in order for this
%  M-file to work
c=csvread('QQQQdata2.csv',1,4,[1 4 50 4]);
for n =5:50;
    y(n)=.0625*c(n)+.25*c(n-1)+.375*c(n-2)+.25*c(n-3)+.0625*c(n-4);
end;
n=5:50;
plot(n,c(n),'k',n,c(n),'ok',n,y(n),'k',n,y(n),'k*')
grid
xlabel('Day (n)')
ylabel('c[n] and y[n]')
title('Figure 5.29')

