%  Figure 7.11
%  plots closing price c[n] of QQQQ and MACD signal
%  c[n] plotted using o's
%  y[n] plotted usiing *'s
c=csvread('QQQQdata3.csv',1,4,[1 4 149 4]);
y1(1)=c(1);
for i=2:149;
    y1(i)=y1(i-1)+.2*(c(i)-y1(i-1));
end;
y2(1)=c(1);
for i=2:149;
    y2(i)=y2(i-1)+.1*(c(i)-y2(i-1));
    D(i)=y1(i)-y2(i);
end;
n=2:149;
subplot(211),plot(n,D(n),'k',n,D(n),'k.')
grid
xlabel('Day (n)')
ylabel('Difference in filter outputs')
title('Figure 7.11 (a)')
subplot(212),plot(n,c(n),'k',n,c(n),'k.')
grid
xlabel('Day (n)')
ylabel('c[n]')
title('Figure 7.11 (b)')

subplot(111)


