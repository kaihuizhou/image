% Example 2.12, use of the ODE solver
%
tspan = [0 8];  % vector of initial and final times
y0 = 0;  % initial value for y(t)
[t,y] = ode45(@ex2_12_func,tspan,y0);

%  Compare to Euler approximation from Example 2.11
%
R = 1; C = 1; T = .2;
a =-(1-T/R/C); b = [0 T/R/C];
y0 = 0; x0 = 1;
n = 1:40;
x = ones(1,length(n));
y1 = recur(a,b,n,x,x0,y0);          % approximate solution

% compare to exact solution 
t2 = 0:.04:8;
y2 = 1 - exp(-t2);        % exact solution
%
y1 = [y0 y1];            % augments I.C. onto vector for plotting
n = 0:40;		     % redefines n accordingly
plot(n*T,y1,'o',t,y,'--',t2,y2,'-')
%
% the following inserts a legend
legend('Euler Approximation','Runge-Kutta Approximation','Exact Solution');
