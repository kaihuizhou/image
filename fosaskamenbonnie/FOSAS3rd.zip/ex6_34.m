% Example 6.34
syms s H X Y
H = 2/(s^2+4*s+4);
X = 1/s;
Y = H*X;
y = ilaplace(Y) % use simplify(y) to simplify result
ezplot(y,[0,10]);
axis([0 10 0 .75])
