% Example 9.8
num = [1 3];
den = [1 1 3 -5];
rlocus(num,den)