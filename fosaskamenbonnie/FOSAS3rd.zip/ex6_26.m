% Example 6.26
%
syms X s x
X = (s+2)/(s^3+4*s^2+3*s);
x = ilaplace(X)
ezplot(x,[0 10])
