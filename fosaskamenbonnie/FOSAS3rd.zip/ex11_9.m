% Example 11.9

A = [0 1;-3 -2]; B = [0 1]'; C = [2 1]; D = 0;
P = [1 1;0 1];
Abar = P*A*inv(P);
Bbar = P*B;
Cbar = C*inv(P);
Dbar = D;

sys1 = ss(A,B,C,D);
sys2 = ss2ss(sys1,P);
tf(sys1)
tf(sys2)