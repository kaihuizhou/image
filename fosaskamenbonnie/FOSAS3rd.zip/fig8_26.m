% Figure 8.26
w=logspace(-2,2,200); s = j*w;
% exact plot 
H = s;
mag = 20*log10(abs(H));
clf
subplot(211),semilogx(w,mag);
ylabel('Magnitude, dB')
axis([.01 100 -40 40]);
grid
subplot(212),semilogx(w,angle(H)*180/pi);
ylabel('Angle, degrees')
axis([.01 100 0 180]);
ytick = [0 90 180];
set(gca,'ytick',ytick);
xlabel('Frequency, (rad/s)')
grid
subplot(111)