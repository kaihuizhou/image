%  Example 8.8
% second order response
%  real poles

% using the step command
t = 0:.01:8;
p1 = -1; p2 = -2;
num = 2; den = [1 3 2];
H = tf(num,den);
y = step(H,t);
plot(t,y);
xlabel('Time (sec)')
ylabel('y(t)')
title('Second order step response: p1 = -1 and p2 = -2')

% using the symbolic manipulator
syms X H s
X = 1/s; H = 2/(s+1)/(s+2);
ezplot(ilaplace(X*H));
axis([0 8 0 1])
xlabel('Time (sec)')
ylabel('y(t)')
title('Second order step response: p1 = -1 and p2 = -2')
