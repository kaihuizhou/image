%  Figure 4.30
%  plots sampled signal x[n]
rand('state',0);
n=1:200;
x=.3*sin(0.112*pi*n)+rand(1,200)-0.5;
plot(n,x,'k');
grid
xlabel('n')
ylabel('Sampled Signal x[n]')
title('Figure 4.30')
pause

X=abs(fft(x));
k=0:199;
h=[];
plot(k,X(k+1),'k');
xlabel('k')
ylabel('|Xk|')
title('Figure 4.31')
pause

k=0:25;
h=[];
stem(k,X(k+1),'filled','k')
xlabel('k')
ylabel('|Xk|')
title('Figure 4.32')


