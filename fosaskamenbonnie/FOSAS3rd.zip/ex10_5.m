% Example 10.5
%
N = 2;    % number of poles
T = .2;   % sampling period
wc = 2;   % analog cutoff frequency
Wc = wc*T/pi;    % normalized digital cutoff frequency
[numd,dend] = butter(N,Wc)