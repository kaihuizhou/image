% Example 7.17
%
num = [1 0 0 1];
den = [1 -1 -1 -2 0];
[r,p] = residue(num,den)
disp('Hit return to continue')
pause
% numerical method
den = [1 -1 -1 -2];
x = filter(num,den,[1 zeros(1,19)])
