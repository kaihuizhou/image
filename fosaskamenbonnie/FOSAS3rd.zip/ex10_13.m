% Example 10.13

wn = sqrt(2);
T = 2*pi/wn/20
Np = 10; % plant
Dp = [1 .1 0];
clf
for i = 1:4;
   T = input('T = ');
   Nc = .2*[1 .1]; % analog controller
Dc = [1 2];
[Nd,Dd] = bilinear(Nc,Dc,1/T) % digital controller
t = 0:.5*T:10;
u = ones(1,length(t)); % step input

[theta,uc] = hybrid(Np,Dp,Nd,Dd,T,t,u);
plot(t,theta)
hold on
pause
end
hold off

