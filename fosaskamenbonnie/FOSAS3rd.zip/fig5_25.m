%  Figure 5.25
%  plots magnitude and phase functions of 3-point MA filter
W=0:.01:1; 
HH=(1/3)*(1-exp(-j*3*pi*W))./(1-exp(-j*pi*W));
magH=abs(HH);
angH=180*angle(HH)/pi;
subplot(211),plot(W,magH,'k')
grid
xlabel('Normalized frequency')
ylabel('|H|')
pubplot
title('Figure 5.25 (a)')
subplot(212),plot(W,angH,'k')
grid
xlabel('Normalized frequency')
ylabel('angle(H) in degrees')
title('Figure 5.25 (b)')

subplot(111)
