% Example 2.16
% Convolution of exponentials

%
syms t lambda y
y = int(exp(2*lambda-t),lambda,0,t);     % for 0<t<1
simplify(y)

y = int(exp(2*lambda-t),lambda,0,1)+int(exp(2-t),lambda,1,t);  % for 1<t<2
simplify(y)

y = int(exp(2*lambda-t),lambda,0,1)+int(exp(2-t),lambda,1,2);  % for 2<t<4
simplify(y)

y=int(exp(2*lambda-t),lambda,t-4,1)+int(exp(2-t),lambda,1,2);  % for 4<t<5
simplify(y)

y=int(exp(2-t),lambda,t-4,2)  % for 5<t<6
simplify(y)

