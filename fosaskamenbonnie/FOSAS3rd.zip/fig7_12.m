%  Figure 7.12
%  plots closing price c[n] of QQQQ for 3/1/04 through 7/22/04
c=csvread('QQQQdata4.csv',1,4,[1 4 100 4]);
n=1:100;
plot(n,c(n),'k',n,c(n),'k.')
grid
xlabel('Day (n)')
ylabel('c[n]')
title('Figure 7.12')



