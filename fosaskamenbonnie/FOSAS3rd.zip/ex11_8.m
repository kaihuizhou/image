%Example 11.8

A = [0 -1 0;1 0 0;0 1 0]; B = [1 0 1;0 1 0;0 0 1];
C = [0 1 0;1 0 1]; D = [0 0 0;0 1 0];
x0 = [1 1 0]';	% define the I.C.
n = 0:1:10;
v = zeros(length(n),3);
[y,x] = dlsim(A,B,C,D,v,x0);

sys = ss(A,B,C,D);
tf(sys)

