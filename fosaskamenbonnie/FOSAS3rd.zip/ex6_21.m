% Example 6.21
num = [5 -1];
den = [1 0 -3 -2];
[r,p] = residue(num,den)