% Example 9.3
p = [1 14 51 103 2];
roots(p)