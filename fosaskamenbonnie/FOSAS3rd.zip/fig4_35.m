%  Figure 4.35
%
spd=csvread('sunspotdata.csv',0,2,[0 2 299 2]);
x=spd-(1/300)*sum(spd);
X=abs(fft(x));
k=0:10;
h=[];
H=stem(k,X(k+1),'filled','k');
xlabel('k')
ylabel('|Xk|')
%title('Figure 4.35')
pubplot
print -dill \book\plotting\fig4_35
