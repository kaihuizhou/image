%  Figure 4.36
%  spectrum of w[k]
spd=csvread('sunspotdata.csv',0,2,[0 2 299 2]);
for n=1:264;
    v(n)=spd(n+36);
end;
w=v-(1/264)*sum(v);
W=abs(fft(w));
k=0:10;
h=[];
H=stem(k,W(k+1),'filled','k')
xlabel('k')
ylabel('|Wk|')
%title('Figure 4.36')
pubplot
print -dill \book\plotting\fig4_36
