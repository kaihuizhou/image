% Figure 8.18
clf 
w = 0:.05:10; s = j*w;
H = 2./(s+2);
subplot(211),plot(w,abs(H));
xlabel('Frequency (rad/sec)')
ylabel('|H|')
title('Figure 8.18')
subplot(212),plot(w,angle(H)*180/pi);
axis([0 10 -90 0])
xlabel('Frequency (rad/sec)')
ylabel('Angle(H), degrees')
subplot(111)