% Example 10.1
%
w = -pi:2*pi/300:pi;
z = exp(-j*w);
H = 0.0302*(z.^2 + 2*z + 1)./(z.^2 - 1.4514*z + 0.5724);
plot(w,abs(H))
axis([-pi pi 0 1])
title('Figure 10.6')
ylabel('|Hd|')
xlabel('\Omega')
% The following adds text to the plot.
hold on
plot([w(1) .3948],[.707 .707],'r--',[.3948 .3948],[0 .707],'r--')
text(1,.7,'W','FontName','Symbol')
text(1.15,.7,'c = 0.3948')
hold off