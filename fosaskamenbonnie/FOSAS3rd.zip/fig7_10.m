%  Figure 7.10
%  plots output y[n] of IIR EWMA filter applied to closing price c[n] of QQQQ
%  c[n] plotted using o's
%  y[n] plotted using *'s
c=csvread('QQQQdata2.csv',1,4,[1 4 50 4]);
y(1)=c(1);
for i=2:50;
    y(i)=y(i-1)+.2*(c(i)-y(i-1));
end;
n=2:50;
plot(n,c(n),'k',n,c(n),'ko',n,y(n),'k',n,y(n),'k*')
grid
xlabel('Day (n)')
ylabel('c[n] and y[n]')
title('Figure 7.10')
