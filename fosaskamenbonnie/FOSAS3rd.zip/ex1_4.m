%  Example 1.4
%  closing price c[n] plotted using o's
%  11-day MA filter output y[n] plotted using *'s
c=csvread('QQQQdata2.csv',1,4,[1 4 50 4]);
for i=11:50;
    y(i)=(1/11)*sum(c(i-10:i));
end;
n=11:50;
plot(n,c(n),n,c(n),'o',n,y(n),n,y(n),'*')
grid
xlabel('Day (n)')
ylabel('c[n] and y[n]')
title('Figure 1.27')
pause
%
%  plot of c[n] and y[n+5] 
n=6:45;
plot(n,c(n),n,c(n),'o',n,y(n+5),n,y(n+5),'*')
axis([5 45 34 37.5])
grid
xlabel('Day (n)')
ylabel('c[n] and y[n+5]')
title('Figure 1.28')

