% Example 7.8
x = [1 2 2 1];
Xk = dft(x)