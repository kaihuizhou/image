% Example 10.3
c = csvread('QQQQdata2.csv',1,4,[1 4 50 4]');
y(1)=c(1);y(2)=c(2);
for i=3:50;
    y(i)=1.444*y(i-1)-0.5682*y(i-2)+0.0309*[c(i)+2*c(i-1)+c(i-2)];
end;
n=1:50;
plot(n,c,'r',n,c,'ro',n,y,'b',n,y,'b*');
xlabel('Day (n)')
ylabel('c[n] and y[n]')


