% Example 9.12
num = conv([1 1],[1 8]);
den = [1 5 4 0];
rlocus(num,den)
title('Example 9.12')