%  Example 5.26
%  compares frequency response of WMA filter and 2-point MA filter
%  dotted curve is the frequency response of the 2-point MA filter
W=0:.01:1; 
H1=(1/2)*(1-exp(-j*2*pi*W))./(1-exp(-j*pi*W));
H2=.25+.5*exp(-j*W*pi)+.25*exp(-j*2*W*pi);
magH1=abs(H1);
magH2=abs(H2);
plot(W,magH2,'k',W,magH1,'k.')
grid
xlabel('Normalized frequency')
ylabel('|H|')
title('Figure 5.26')

