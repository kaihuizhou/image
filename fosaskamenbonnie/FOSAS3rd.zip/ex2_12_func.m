% function that computes the dy/dt for RC circuit
function dy = ex2_12_func(t,y);
R = 1; C = 1; x = 1;
dy = x/C/R - y(1)/C/R;
