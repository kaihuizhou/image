% Example 8.9
% second order response
%  real and equal poles

% The user should remove the portions of the code
%   that use a toolbox that he/she does not have.

% This portion of the code requires the Control Systems Toolbox.
t = 0:.01:8;
p1 = -1; p2 = -2;
num = 4; den = [1 4 4];
H = tf(num,den);
y = step(H,t);
plot(t,y);
xlabel('Time (sec)')
ylabel('y(t)')
title('Second order step response: p1 = p2 = -2')

% This portion of the code requires the Symbolic Math Toolbox.
syms X H s
X = 1/s; H = 4/(s+2)/(s+2);
y = ilaplace(H*X);
ezplot(y,[0, 8, 0, 1]);
xlabel('Time (sec)')
ylabel('y(t)')
title('Second order step response: p1 = p2 = -2')
