% Example 6.23
num = [1 0 2 -4];
den = [1 4 -2];
[Q,R] = deconv(num,den)

num = [20 -12];
den = [1 4 -2];
[r,p] = residue(num,den)