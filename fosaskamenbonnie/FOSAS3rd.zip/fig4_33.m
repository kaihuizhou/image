%  Figure 4.33
%  plots sunspot data
spd=csvread('sunspotdata.csv',0,2,[0 2 299 2]);
h=[];
H=plot(spd,'k')
axis([0 300 0 200]);
grid
xlabel('Month')
ylabel('Average Number of Sunspots')
%title('Figure 4.33')
pubplot
print -dill \book\plotting\fig4_33
