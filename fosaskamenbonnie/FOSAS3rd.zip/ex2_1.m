%  Example 2.1
%  closing price c[n] plotted using o's
%  11-day EWMA filter output y[n] plotted using *'s
c=csvread('QQQQdata2.csv',1,4,[1 4 50 4]);
b=0.7;
a=(1-b)/(1-b^11);
i=1:11;
w=a*(b.^(11-i));
for n=11:50;
    y(n)=w*c(n-10:n);
end;
n=11:50;
plot(n,c(n),n,c(n),'o',n,y(n),n,y(n),'*')
grid
xlabel('Day (n)')
ylabel('c[n] and y[n]')
title('Figure 2.1')
hold on
pause
%
%  Add 11-day MA filter output to plot, denoted by +'s
for n=11:50;
    MA(n)=(1/11)*sum(c(n-10:n));
end;
n=11:50;
plot(n,MA(n),n,MA(n),'+')
xlabel('Day (n)')
ylabel('c[n] and filter  outputs')
title('Figure 2.2')
grid;grid
hold off


