%  Figure 4.38
%  Aplitude spectrum of x[n]
c=csvread('QQQQdata2.csv',1,4,[1 4 50 5]);
x=[];
for n=1:50;
    x(n)=c(n)-c(1)+(c(1)-c(50))*(n-1)/49;
end;
X=abs(fft(x));
k=0:49;
H=stem(k,X(k+1),'filled','k')
xlabel('k')
ylabel('|Xk|')
%title('Figure 4.38')
pubplot
print -dill \book\plotting\fig4_38

