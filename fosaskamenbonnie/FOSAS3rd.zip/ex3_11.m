% Example 3.11
% Fourier Transform of triangular pulse

syms x t w X
tau = 1;
X = int((1-2*abs(t)/tau)*exp(-i*w*t),t,-tau/2,tau/2);
simplify(X)

% results in -4*(cos(1/2*w)-1)/w^2
% defined nonsymbolic terms for plotting
tp1 = -tau:.02:-tau/2; tp2 = -tau/2+0.02:0.02:tau/2;
tp3 = tau/2+.02:.02:tau;
xp = [zeros(size(tp1)),(1-2*abs(tp2)/tau),zeros(size(tp3))];
wp = -40:.07:40;
Xp = -4*(cos(1/2*wp)-1)./wp.^2;
subplot(222),plot(wp,abs(Xp))
xlabel('Frequency (rad/sec)')
ylabel('|X|')
subplot(221), plot([tp1, tp2, tp3],xp)
xlabel('x(t)')
ylabel('Time (sec)')

% compare to the rectangular pulse

X = int(exp(-i*w*t),t,-tau/2,tau/2)
simplify(X)
% results in -2*sin(1/2*w)/w

xp = [zeros(size(tp1)),ones(size(tp2)),zeros(size(tp3))];
Xp = 2*sin(1/2*wp)./wp;
subplot(224),plot(wp,abs(Xp))
xlabel('Frequency (rad/sec)')
ylabel('|X|')
subplot(223), plot([tp1, tp2, tp3],xp)
xlabel('x(t)')
ylabel('Time (sec)')
subplot(111)