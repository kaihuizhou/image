% Example 6.3
% Laplace Transform Using Symbolic Manipulation
syms x b t
x = exp(-b*t);
X = laplace(x)
%

x = sym(1);   % creates a symbolic expression for 1
X = laplace(x)
