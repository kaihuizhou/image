%  Example 8.15
% third order response
%   shows dominant poles
% no zeros

% The user should remove the portions of the code that require
%   a toolbox that they do not have.

% This portion of the code requires the Control Systems Toolbox.
num = 25;  % this multiplies the polynomials
den = conv([1 7 25],[1 1]); % this multiplies the polynomials
H = tf(num,den);
t = 0:0.01:4;
y1 = step(tf,t);
% with a zero at 0.9
num2 = [1 0.9]/0.9;
num =25*num2;
H = tf(num,den);
y2 = step(H,t);
plot(t,y1,t,y2);
xlabel('Time (sec)')
ylabel('y(t)')
title('Third order step response, no zeros')
text(1.2,.5,'no zeros')
text(.5,.8,'zero at -0.9')

% This portion of the code requires the Symbolic Math Toolbox.
syms Y y s
Y = 25/(s^2+7*s+25)/(s+1)/s;  % rerun with a zero at s = -0.9
y = ilaplace(Y);
ezplot(y,[0 4])
axis([0 4 0 1.5])
xlabel('Time (sec)')
ylabel('y(t)')
title('Third order step response, no zeros')
